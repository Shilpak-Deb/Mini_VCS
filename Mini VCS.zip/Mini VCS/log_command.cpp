#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the log command
void log() {

    //Stores the path of the log file (commit history)
    string log_path = ".mygit/log";

    //Checking if log file is empty (no commits made yet) 
    if(file_size(log_path) == 0) {
        cerr << "./mygit: log: No commits have been made yet!" << endl;
        exit(1);
    }

    string log_data = read_file(log_path);
    vector<string> log_lines = tokenize(log_data, "\n");

    vector<vector<string>> commits;
    for(int i = 0; i < log_lines.size(); i += 5) {
        vector<string> single_commit;
        for(int j = i; j < i + 5; j++) single_commit.push_back(log_lines[j]);
        commits.push_back(single_commit);
    }

    //Displaying the commits in reverse order (latest first)
    for(int i = commits.size() - 1; i >= 0; i--) {
        cout << "Commit SHA: " << commits[i][0] << endl;
        cout << "Parent Commit SHA: " << commits[i][1] << endl;
        cout << "Date: " << commits[i][2] << endl;
        cout << "Committed By: " << commits[i][3] << endl;
        cout << "Message: " << commits[i][4] << endl;
        cout << endl;
    }
}


