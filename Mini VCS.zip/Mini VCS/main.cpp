#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

int main(int argcount, char* arguments[]) {

    //Checking if any arguments have been provided
    if(argcount < 2) {
        cerr << "./mygit: No arguments provided!" << endl;
        return -1;
    }

    string command = arguments[1];

    //init
    if(command == "init") {

        //Checking if no. of arguments are valid
        if(argcount < 2) {
            cerr << "./mygit init: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 2) {
            cerr << "./mygit init: Too many arguments!" << endl;
            return -1;
        }

        init();
    }

    //hash-object
    else if(command == "hash-object") {
        
        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        string flag = "none";
        string filepath = "";

        //Checking if no. of arguments are valid
        if(argcount < 3) {
            cerr << "./mygit hash-object: Too few arguments!" << endl;
            return -1;
        }
        if(string(arguments[2]) != "-w") {
            if(argcount > 3) {
                cerr << "./mygit hash-object: Too many arguments!" << endl;
                return -1;
            }
            filepath = arguments[2];
        }
        else {
            if(argcount < 4) {
                cerr << "./mygit hash-object: Too few arguments!" << endl;
                return -1;
            }
            if(argcount > 4) {
                cerr << "./mygit hash-object: Too many arguments!" << endl;
                return -1;
            }
            flag = arguments[2];
            filepath = arguments[3];
        }
        
        if(flag == "none") hash_object(filepath, false);
        if(flag == "-w") hash_object(filepath, true);
    }

    //cat-file
    else if(command == "cat-file") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        string flag = "none";
        string hash = ""; 

        //Checking if no. of arguments are valid
        if(argcount < 4) {
            cerr << "./mygit cat-file: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 4) {
            cerr << "./mygit cat-file: Too many arguments!" << endl;
            return -1;
        }

        flag = arguments[2];
        hash = arguments[3];

        //Checking if a valid flag was entered
        if(flag != "-p" && flag != "-s" && flag != "-t") {
            cerr << "./mygit cat-file: Invalid flag!" << endl;
            return -1;
        }

        if(flag == "none") cat_file(hash, false, false, false);
        if(flag == "-p") cat_file(hash, true, false, false);
        if(flag == "-s") cat_file(hash, false, true, false);
        if(flag == "-t") cat_file(hash, false, false, true);
    }

    //write-tree
    else if(command == "write-tree") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        //Checking if no. of arguments are valid
        if(argcount < 2) {
            cerr << "./mygit write-tree: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 2) {
            cerr << "./mygit write-tree: Too many arguments!" << endl;
            return -1;
        }

        write_tree();
    }

    //ls-tree
    else if(command == "ls-tree") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        string flag = "none";
        string hash = "";

        //Checking if no. of arguments are valid
        if(argcount < 3) {
            cerr << "./mygit ls-tree: Too few arguments!" << endl;
            return -1;
        }
        if(string(arguments[2]) != "--name-only") {
            if(argcount > 3) {
                cerr << "./mygit ls-tree: Too many arguments!" << endl;
                return -1;
            }
            hash = arguments[2];
        }
        else {
            if(argcount < 4) {
                cerr << "./mygit ls-tree: Too few arguments!" << endl;
                return -1;
            }
            if(argcount > 4) {
                cerr << "./mygit ls-tree: Too many arguments!" << endl;
                return -1;
            }
            flag = arguments[2];
            hash = arguments[3];
        }
        
        if(flag == "none") ls_tree(hash, false);
        if(flag == "--name-only") ls_tree(hash, true);
    }

    //add
    else if(command == "add") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        vector<string> paths;

        //Checking if no. of arguments are valid
        if(argcount < 3) {
            cerr << "./mygit add: Too few arguments!" << endl;
            return -1;
        }

        for(int i = 2; i < argcount; i++) paths.push_back(string(arguments[i]));

        for(int i = 0; i < paths.size(); i++) {
            if(paths[i] == ".") add(paths[i], true);
            else add(paths[i], false);
        }
    }

    //commit
    else if(command == "commit") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        string flag = "none";
        string message = "";

        //Checking if no. of arguments are valid
        if(argcount < 2) {
            cerr << "./mygit commit: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 2) {
            if(argcount < 4) {
                cerr << "./mygit commit: Too few arguments!" << endl;
                return -1;
            }
            if(string(arguments[2]) != "-m") {
                cerr << "./mygit commit: Invalid flag!" << endl;
                return -1;
            }

            flag = arguments[2];
            for(int i = 3; i < argcount; i++) message += string(arguments[i]) + " ";
        }

        if(flag == "-m") commit(true, message);
        if(flag == "none") commit(false, message);
    }

    //log
    else if(command == "log") {

        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        //Checking if no. of arguments are valid
        if(argcount < 2) {
            cerr << "./mygit log: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 2) {
            cerr << "./mygit log: Too many arguments!" << endl;
            return -1;
        }

        log();
    }

    //checkout
    else if(command == "checkout") {
        //Checking if init command has been used beforehand
        if(!dir_exists(".mygit")) {
            cerr << "./mygit: Not initialized" << endl;
            return -1;
        }

        //Checking if no. of arguments are valid
        if(argcount < 3) {
            cerr << "./mygit checkout: Too few arguments!" << endl;
            return -1;
        }
        if(argcount > 3) {
            cerr << "./mygit checkout: Too many arguments!" << endl;
            return -1;
        }

        string commmit_hash = arguments[2];

        checkout(commmit_hash);
    }

    //INVALID COMMAND
    else {
        cerr << "./mygit: Invalid command!" << endl;
        return -1;
    }

    return 0;
}