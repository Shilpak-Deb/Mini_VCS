#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the add command
void add(string path, bool add_all) {

    //Stores the path of the index file (staging area)
    string index_path = ".mygit/index";

    //Stores path of blob and tree directories
    string blob_dir_path = ".mygit/objects/blobs/";
    string tree_dir_path = ".mygit/objects/trees/";

    //Add all files/directories (.)
    if(add_all) {
        //Overwriting tree object for given directory
        string hash = write_tree(path);
        string type = "tree";
        string permissions = get_permissions(path);

        //Adding hash and other details to index file
        string details = permissions + " " + type + " " + hash + " " + path + "\n";
        int index_fd = open(index_path.c_str(), O_WRONLY | O_TRUNC);    //Since all files (entire directory is being added - all other contents are redundant)

        //Error handling
        if(index_fd == -1) {
            perror("./mygit: add: Could not open index file");
            return;
        }
        if(write(index_fd, details.c_str(), details.size()) == -1) {
            perror("./mygit: add: Could not write to index file");
            close(index_fd);
            return;
        }

        close(index_fd);
    }
    
    //Add specific files/directories
    else {

        //Checks if the path provided is valid (either file or directory)
        bool is_file = file_exists(path);
        bool is_directory = dir_exists(path);

        if(!is_file && !is_directory) {
            cerr << "./mygit: add: " << path << ": No such file or directory!" << endl;
            return;
        }

        //Checks if the index file is empty
        if(file_size(index_path) == 0) {
            //Adding the hash of current working directory to first line of index (to know where to begin restoring from during commit)
            string cwd_hash = write_tree(".");
            string cwd_type = "tree";
            string cwd_path = ".";
            string cwd_permissions = get_permissions(cwd_path);
            
            //Adding hash and other details to index file
            string details = cwd_permissions + " " + cwd_type + " " + cwd_hash + " " + cwd_path + "\n";
            int index_fd = open(index_path.c_str(), O_WRONLY | O_TRUNC); 

            //Error handling
            if(index_fd == -1) {
                perror("./mygit: add: Could not open index file");
                return;
            }
            if(write(index_fd, details.c_str(), details.size()) == -1) {
                perror("./mygit: add: Could not write to index file");
                close(index_fd);
                return;
            }

            close(index_fd);
        }

        //File
        if(is_file) {
            //Checking if blob object of file exists
            string hash = SHA1_hash(path);
            string type = "blob";
            string permissions = get_permissions(path);
            
            //Creating new hash file if it doesn't exist
            if(!file_exists(blob_dir_path + hash)) {
                hash = hash_object(path);
            }

            //Adding hash and other details to index file
            string details = permissions + " " + type + " " + hash + " " + path + "\n";
            int index_fd = open(index_path.c_str(), O_WRONLY | O_APPEND);

            //Error handling
            if(index_fd == -1) {
                perror("./mygit: add: Could not open index file");
                return;
            }
            if(write(index_fd, details.c_str(), details.size()) == -1) {
                perror("./mygit: add: Could not write to index file");
                close(index_fd);
                return;
            }

            close(index_fd);
        }

        //Directory
        if(is_directory) {
            //Overwriting tree object for given directory
            string hash = write_tree(path);
            string type = "tree";
            string permissions = get_permissions(path);

            //Adding hash and other details to index file
            string details = permissions + " " + type + " " + hash + " " + path + "\n";
            int index_fd = open(index_path.c_str(), O_WRONLY | O_APPEND);

            //Error handling
            if(index_fd == -1) {
                perror("./mygit: add: Could not open index file");
                return;
            }
            if(write(index_fd, details.c_str(), details.size()) == -1) {
                perror("./mygit: add: Could not write to index file");
                close(index_fd);
                return;
            }

            close(index_fd);
        }
    }
}


