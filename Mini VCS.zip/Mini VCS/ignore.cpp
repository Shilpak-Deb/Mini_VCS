#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to check if certain files/directories can be ignored
bool mygit_ignore(string fd_name) {
    vector<string> ignore_names = {".", "..", ".mygit", "mygit", ".vscode"};

    for(int i = 0; i < ignore_names.size(); i++) {
        if(fd_name == ignore_names[i]) return true;
    }

    return false;
}