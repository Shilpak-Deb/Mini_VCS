#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to check if a directory exists
bool dir_exists(string path) {
    DIR* dir = opendir(path.c_str());
    if(dir) {
        closedir(dir);
        return true;
    }
    return false;
}

//Function to remove a directory
bool remove_dir(string path) {
    DIR* dir = opendir(path.c_str());
    if (!dir) {
        perror("remove_dir: Error opening directory");
        return false;
    }

    struct dirent* entry;
    vector<string> entries;

    while((entry = readdir(dir)) != NULL) {
        string entry_name = entry->d_name;
        if(!mygit_ignore(entry_name)) {
            entries.push_back(entry_name);
        } 
    }

    closedir(dir);

    for(int i = 0; i < entries.size(); i++) {
        string entry_path = path + "/" + entries[i];
        struct stat entry_stat;

        if(stat(entry_path.c_str(), &entry_stat) == 0) {

            //Deleting a directory (recursive)
            if(S_ISDIR(entry_stat.st_mode)) {
                if(!remove_dir(entry_path)) {
                    cerr << "remove_dir: Failed to remove directory in: " << entry_path << endl;
                    return false;
                }
            }

            //Deleting a file
            else {
                if(unlink(entry_path.c_str()) != 0) {
                    perror(("remove_dir: Failed to remove file in: " + entry_path).c_str());
                    return false;
                }
            }
        }
    }

    if(rmdir(path.c_str()) != 0) {
        perror(("remove_dir: Failed to remove directory in: " + path).c_str());
        return false;
    }

    return true;
}

//Function to empty a directory of its contents
bool empty_directory(string path) {
    DIR* dir = opendir(path.c_str());
    if (!dir) {
        perror("remove_dir: Error opening directory");
        return false;
    }

    struct dirent* entry;
    vector<string> entries;

    while((entry = readdir(dir)) != NULL) {
        string entry_name = entry->d_name;
        if(!mygit_ignore(entry_name)) {
            entries.push_back(entry_name);
        } 
    }

    closedir(dir);

    for(int i = 0; i < entries.size(); i++) {
        string entry_path = path + "/" + entries[i];
        struct stat entry_stat;

        if(stat(entry_path.c_str(), &entry_stat) == 0) {

            //Deleting a directory (recursive)
            if(S_ISDIR(entry_stat.st_mode)) {
                if(!remove_dir(entry_path)) {
                    cerr << "remove_dir: Failed to remove directory in: " << entry_path << endl;
                    return false;
                }
            }

            //Deleting a file
            else {
                if(unlink(entry_path.c_str()) != 0) {
                    perror(("remove_dir: Failed to remove file in: " + entry_path).c_str());
                    return false;
                }
            }
        }
    }

    return true;
}

//Function to create a directory
bool create_dir(string path, int permissions) {
    if(mkdir(path.c_str(), permissions) == 0) return true;
    else {
        perror(("create_dir: Failed to create directory in: " + path).c_str());
        return false;
    }
}

//Function to check if a file exists
bool file_exists(string path) {
    struct stat buffer;   
    return (stat(path.c_str(), &buffer) == 0) && S_ISREG(buffer.st_mode);
}

//Function to remove a file
bool remove_file(string path) {
    if(unlink(path.c_str()) == 0) return true; 
    else {
        perror(("remove_file: Failed to remove file in: " + path).c_str());
        return false;
    }
}

//Function to empty a file
bool empty_file(string path) {
    int fd = open(path.c_str(), O_WRONLY | O_TRUNC);
    
    if(fd == -1) {
        perror(("empty_file: Failed to empty file in: " + path).c_str());
        return false;
    }

    close(fd);
    return true;
}

//Function to create a file
bool create_file(string path, int permissions) {
    int fd = open(path.c_str(), O_CREAT | O_WRONLY, permissions);

    if(fd == -1) {
        perror(("create_file: Failed to create file in: " + path).c_str());
        return false;
    }
    close(fd);
    return true;
}

//Function to read the complete contents of a file and return it as a string
string read_file(string filepath) {
    if(!file_exists(filepath)) {
        cerr << "./mygit: read_file: Invalid file path: " << filepath << "!" << endl;
        exit(1);
    }

    int fd = open(filepath.c_str(), O_RDONLY);

    //Reading from file in chunks and storing it in a string
    char buffer[BUFFER_SIZE];
    int bytes_r;
    string file_contents = "";

    while((bytes_r = read(fd, buffer, BUFFER_SIZE)) > 0) {
        file_contents.append(buffer, bytes_r);
    }

    //Error handling
    if(bytes_r == -1) {
        perror(("./mygit: read_file: Could not read from file in: " + filepath).c_str());
        exit(1);
    }

    close(fd);

    return file_contents;
}

//Function to compress a file and return it as a string
string compress_file(string filepath) {
    if(!file_exists(filepath)) {
        cerr << "./mygit: compress_file: Invalid file path: " << filepath << "!" << endl;
        exit(1);
    }

    int fd = open(filepath.c_str(), O_RDONLY);

    //Reading from file in chunks and storing it in a string
    char buffer[BUFFER_SIZE];
    int bytes_r;
    string file_contents = "";

    while((bytes_r = read(fd, buffer, BUFFER_SIZE)) > 0) {
        file_contents.append(buffer, bytes_r);
    }

    //Error handling
    if(bytes_r == -1) {
        perror(("./mygit: compress_file: Could not read from file in: " + filepath).c_str());
        exit(1);
    }

    close(fd);

    //Preliminary steps for file compression
    uLong source_len = file_contents.size();        //Size of original file contents
    uLong dest_len = compressBound(source_len);     //Setting maximum size for compressed data
    string compressed_data(dest_len, '\0');          //Pre-allocating enough space to store compressed data

    //Compressing file contents
    int result = compress(reinterpret_cast<Bytef*>(&compressed_data[0]), &dest_len, reinterpret_cast<const Bytef*>(file_contents.data()), source_len);

    //Error handling
    if(result != Z_OK) {
        cerr << "./mygit: compress_file: Error encountered during compression: " << result << endl;
        exit(1);
    }

    //Resizing the string to the actual compressed size
    compressed_data.resize(dest_len);

    return compressed_data;
}

//Function to decompress a file and return it as a string
string decompress_file(string filepath) {
    if(!file_exists(filepath)) {
        cerr << "./mygit: decompress_file: Invalid file path: " << filepath << "!" << endl;
        exit(1);
    }

    int fd = open(filepath.c_str(), O_RDONLY);

    //Reading from file in chunks and storing it in a string
    char buffer[BUFFER_SIZE];
    int bytes_r;
    string file_contents = "";

    while((bytes_r = read(fd, buffer, BUFFER_SIZE)) > 0) {
        file_contents.append(buffer, bytes_r);
    }

    //Error handling
    if(bytes_r == -1) {
        perror(("./mygit: decompress_file: Could not read from file in: " + filepath).c_str());
        exit(1);
    }

    close(fd);

    //Preliminary steps for file decompression
    string decompressed_data(BUFFER_SIZE, '\0');
    int result;
    int buffer_size = BUFFER_SIZE;  //Initial size of buffer
    uLongf dest_len = buffer_size;  //Length of decompressed buffer


    //Decompressing until it succeeds or no more buffer errors
    while ((result = uncompress(reinterpret_cast<Bytef*>(&decompressed_data[0]), &dest_len, reinterpret_cast<const Bytef*>(file_contents.data()), file_contents.size())) == Z_BUF_ERROR) {
        //Doubling the buffer size and trying again
        buffer_size *= 2;
        decompressed_data.resize(buffer_size);
        dest_len = buffer_size;
    }

    //Error handling
    if(result != Z_OK) {
        cerr << "./mygit: decompress_file: Error encountered during decompression: " << result << endl;
        return "";
    }

    //Resizing the string to the actual decompressed size
    decompressed_data.resize(dest_len);

    return decompressed_data;   
}

//Function to find file size based on path provided
int file_size(string file_path) {
    struct stat file_stat;

    if (stat(file_path.c_str(), &file_stat) == -1) {
        perror("./mygit: file_size: Error in calculating file size");
        return -1;
    }

    return file_stat.st_size;
}

