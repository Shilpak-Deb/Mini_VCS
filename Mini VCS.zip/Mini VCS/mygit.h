#ifndef MYGIT_HEADER
#define MYGIT_HEADER

#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//External Global Variables

//...................//

//Functions

//misc.cpp
string get_permissions(string path);
vector<string> tokenize(string line, string delimiters);
string get_timestamp(string path);
string get_ownername(string path);
int octal(string s);

//ignore.cpp
bool mygit_ignore(string fd_name);

//fileop.cpp
bool dir_exists(string path);
bool remove_dir(string path);
bool empty_directory(string path);
bool create_dir(string path, int permissions = 0755);
bool file_exists(string path);
bool remove_file(string path);
bool empty_file(string path);
bool create_file(string path, int permissions = 0644);
string read_file(string filepath);
string compress_file(string filepath);
string decompress_file(string filepath);
int file_size(string file_path);

//init_command.cpp
void init();

//hash_object_command.cpp
void hash_object(string filepath, bool w_flag);
string hash_object(string filepath);
string SHA1_hash(string filepath);

//cat_file_command.cpp
void cat_file(string hash, bool p_flag, bool s_flag, bool t_flag);

//write_tree_command.cpp
void write_tree();
string write_tree(string path);

//ls_tree_command.cpp
void ls_tree(string hash, bool name_flag);

//add_command.cpp
void add(string path, bool add_all);

//commit_command.cpp
void commit(bool has_msg, string message);

//log_command.cpp
void log();

//checkout_command.cpp
void checkout(string commit_hash);
void restore_object(int permissions, string type, string hash, string path);

#endif