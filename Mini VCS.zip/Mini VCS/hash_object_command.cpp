#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the hash-object command
void hash_object(string filepath, bool w_flag) {

    //Calculating SHA1 hash for file
    string hash = SHA1_hash(filepath);
    cout << hash << endl;

    if(w_flag) {
        string hashfile_path = ".mygit/objects/blobs/" + hash;

        if(!create_file(hashfile_path)) {
            cerr << "./mygit: hash_object: Could not create file at:" << hashfile_path << "!" << endl;
            exit(1);
        }

        string compressed_data = compress_file(filepath);

        int fd = open(hashfile_path.c_str(), O_WRONLY | O_TRUNC);

        if(fd == -1) {
            cerr << "./mygit: hash_object: Could not write into file at:" << hashfile_path << "!" << endl;
            exit(1);
        }
        
        //Error handling
        if(write(fd, compressed_data.c_str(), compressed_data.size()) == -1) {
            cerr << "./mygit: hash_object: Could not write into file at:" << hashfile_path << "!" << endl;
            close(fd);
            exit(1);
        }
    }
} 

//Function to return hash of file and store it in .mygit/objects/blobs (internal version of hash_object command)
string hash_object(string filepath) {

    //Calculating SHA1 hash for file
    string hash = SHA1_hash(filepath);
    string hashfile_path = ".mygit/objects/blobs/" + hash;

    if(!create_file(hashfile_path)) {
        cerr << "./mygit: hash_object: Could not create file at:" << hashfile_path << "!" << endl;
        exit(1);
    }

    string compressed_data = compress_file(filepath);

    int fd = open(hashfile_path.c_str(), O_WRONLY | O_TRUNC);

    if(fd == -1) {
        cerr << "./mygit: hash_object: Could not write into file at:" << hashfile_path << "!" << endl;
        exit(1);
    }
    
    //Error handling
    if(write(fd, compressed_data.c_str(), compressed_data.size()) == -1) {
        cerr << "./mygit: hash_object: Could not write into file at:" << hashfile_path << "!" << endl;
        close(fd);
        exit(1);
    }
    
    return hash;
} 

//Function to calculate hash for a file
string SHA1_hash(string filepath) {
    if(!file_exists(filepath)) {
        cerr << "./mygit: sha1_hash: Invalid file path: " << filepath << "!" << endl;
        exit(1);
    }

    int fd = open(filepath.c_str(), O_RDONLY);
    unsigned char sha1_hash[SHA_DIGEST_LENGTH];     //char array to store SHA1 hash (20 bytes)

    //Calculating the SHA1 hash for given file
    SHA_CTX ctx;                                    //Initializes a context structure (part of OPENSSL library)
    SHA1_Init(&ctx);                                //Initializes the context

    //Reading from file in chunks and updating the sha1 context structure
    char buffer[BUFFER_SIZE];
    int bytes_r;

    while ((bytes_r = read(fd, buffer, BUFFER_SIZE)) > 0) SHA1_Update(&ctx, buffer, bytes_r);

    //Error handling
    if(bytes_r == -1) {
        perror(("./mygit: sha1_hash: Could not read from file in: " + filepath).c_str());
        exit(1);
    }

    close(fd);

    SHA1_Final(sha1_hash, &ctx);

    //Converting result to C++ string for ease of use
    string hash_string;

    char temp[3];  //Buffer to hold 2 hex characters + null terminator

    for (int i = 0; i < SHA_DIGEST_LENGTH; ++i) {
        snprintf(temp, sizeof(temp), "%02x", sha1_hash[i]);     //Converting into a 2-character hexadecimal string
        hash_string += temp;                                      //Appending to hash_string
    }

    return hash_string;
}

