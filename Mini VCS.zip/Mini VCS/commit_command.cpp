#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the commit command
void commit(bool has_msg, string message) {

    //Stores the path of the index file (staging area)
    string index_path = ".mygit/index";

    //Stores the path of the HEAD file (parent commit)
    string head_path = ".mygit/HEAD";

    //Stores the path of the log file (commit history)
    string log_path = ".mygit/log";

    //Stores the path of the commit object directory
    string commit_dir_path = ".mygit/commits/";
    
    //Checking if any files have been added to stage yet
    if(file_size(index_path) == 0) {
        cerr << "./mygit: commit: No file/directories have been added to stage yet!" << endl;
        exit(1);
    }



    //----------------------Creating a new commit object-----------------------//

    string commit_hash = SHA1_hash(index_path);                     //Hash for new commit object (obtained from SHA1 hash of index)
    string commit_file_path = commit_dir_path + commit_hash;        //Path for new commit object to be stored
    string commit_file_contents = read_file(index_path);            //Reading the contents of staging area (index)

    if(!create_file(commit_file_path)) {
        cerr << "./mygit: commit: Could not create file at:" << commit_file_path << "!" << endl;
        exit(1);
    }

    int commit_fd = open(commit_file_path.c_str(), O_WRONLY);

    //Error handling
    if(write(commit_fd, commit_file_contents.c_str(), commit_file_contents.size()) == -1) {
        cerr << "./mygit: commit: Could not write into file at:" << commit_file_path << "!" << endl;
        close(commit_fd);
        exit(1);
    }

    close(commit_fd);



    //-------------------------Updating log-----------------------------//

    string parent_commit_hash = "";

    //Checking if there is parent commit (only if HEAD is non-empty)
    if(file_size(head_path) == 0) {
        for(int i = 0; i < 40; i++) parent_commit_hash += "-";
    }
    else {
        parent_commit_hash = read_file(head_path);
    }

    string timestamp = get_timestamp(commit_file_path);
    string committer_info = get_ownername(commit_file_path);

    //Default message
    if(!has_msg) {
        message = "Added";
        
        vector<string> index_lines = tokenize(commit_file_contents, "\n");
        
        if(index_lines.size() == 1) message += " entire working directory!";
        else {
            for(int i = 1; i < index_lines.size(); i++) {
                vector<string> line_elements = tokenize(index_lines[i], " ");
                message += " " + line_elements[line_elements.size() - 1];
            }
            message += "!";
        }        
    }

    string log_data = commit_hash + "\n" + parent_commit_hash + "\n" + timestamp + "\n" + committer_info + "\n" + message + "\n\n";
    
    //Error handling
    int log_fd = open(log_path.c_str(), O_WRONLY | O_APPEND);

    if(log_fd == -1) {
        cerr << "./mygit: commit: Could not write into file at:" << log_path << "!" << endl;
        exit(1);
    }

    if(write(log_fd, log_data.c_str(), log_data.size()) == -1) {
        cerr << "./mygit: commit: Could not write into file at:" << log_path << "!" << endl;
        close(log_fd);
        exit(1);
    }

    close(log_fd);
    


    //------------------------Updating HEAD-------------------------//

    //Overwriting previous HEAD file
    int head_fd = open(head_path.c_str(), O_WRONLY | O_TRUNC);

    //Error handling
    if(head_fd == -1) {
        cerr << "./mygit: commit: Could not open file at:" << head_path << "!" << endl;
        exit(1);
    }

    if(write(head_fd, commit_hash.c_str(), commit_hash.size()) == -1) {
        cerr << "./mygit: commit: Could not write into file at:" << head_path << "!" << endl;
        close(head_fd);
        exit(1);
    }

    close(head_fd);



    //------------------------Emptying index-------------------------//

    //Error handling
    if(!empty_file(index_path)) {
        cerr << "./mygit: commit: Could not empty index file!" << endl;
        exit(1);
    }

    //------------------------Displaying commit SHA-------------------------//

    cout << commit_hash << endl;
}



