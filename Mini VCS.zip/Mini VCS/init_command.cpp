#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the init command
void init(){
    string init_path = ".mygit";
    
    //Check if .mygit exists
    if(dir_exists(init_path)) {
        //Remove directory if exists
        if(!remove_dir(init_path)) {
            cerr << "./mygit init: Could not remove .mygit directory!" << endl;
            exit(1);
        }
    }

    //Create .mygit
    if(!create_dir(init_path)) {
        cerr << "./mygit init: Could not create .mygit directory!" << endl;
        exit(1);
    }

    //Creating subdirectories and files
    if(!create_dir(init_path + "/objects")) {
        cerr << "./mygit init: Could not create .mygit/objects directory!" << endl;
        exit(1);
    }
    if(!create_dir(init_path + "/objects/blobs")) {
        cerr << "./mygit init: Could not create .mygit/objects/blobs directory!" << endl;
        exit(1);
    }
    if(!create_dir(init_path + "/objects/trees")) {
        cerr << "./mygit init: Could not create .mygit/objects/trees directory!" << endl;
        exit(1);
    }
    if(!create_dir(init_path + "/commits")) {
        cerr << "./mygit init: Could not create .mygit/commits directory!" << endl;
        exit(1);
    }
    if(!create_file(init_path + "/HEAD")) {
        cerr << "./mygit init: Could not create .mygit/HEAD file!" << endl;
        exit(1);
    }
    if(!create_file(init_path + "/index")) {
        cerr << "./mygit init: Could not create .mygit/index file!" << endl;
        exit(1);
    }
    if(!create_file(init_path + "/log")) {
        cerr << "./mygit init: Could not create .mygit/log file!" << endl;
        exit(1);
    }

}



