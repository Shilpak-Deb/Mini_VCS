#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to retrieve permissions in file_format for given path
string get_permissions(string path) {
    struct stat fd_stat;

    if(stat(path.c_str(), &fd_stat) != 0) {
        std::cerr << "./mygit: permissions: Unable to retrieve information for file/directory in: " << path << "!" << endl;
        exit(1);
    }

    string type = "";

    if (S_ISREG(fd_stat.st_mode)) type = "100";         //Regular file
    else if (S_ISDIR(fd_stat.st_mode)) type = "040";    //Directory
    else if (S_ISLNK(fd_stat.st_mode)) type = "120";    //Symbolic link
    else type = "???";                                  //Unknown type

    string permissions = "";

    char permission_buffer[4];  //Buffer for permissions (3 digits + null terminator)
    snprintf(permission_buffer, sizeof(permission_buffer), "%03o", fd_stat.st_mode & 0777);  //Formating permissions to octal

    //Combinining the type and permission strings
    return type + string(permission_buffer);
}

//Function to tokenize a line based on delimiters provided
vector<string> tokenize(string line, string delimiters) {
    if(line.empty()) return {};   //Checks if line is empty
    vector<string> token_list;    //Stores all tokens present in line

    //Tokenizing line via delimiters
    char* argument = strtok(line.data(), delimiters.data());
    while(argument != NULL) {
        token_list.push_back(string(argument));
        argument = strtok(NULL, delimiters.data());
    }

    //Returning the string vector
    return token_list;
}

//Function to get the formatted timestamp (similar to github) for last modification
string get_timestamp(string path) {
    struct stat file_stat;

    //Using stat() to get the file metadata (with error handling)
    if(stat(path.c_str(), &file_stat) == -1) {
        perror("./mygit: timestamp");
        exit(1);
    }

    //Formatting the last modification date
    struct tm* time_info = localtime(&(file_stat.st_mtime));  //Converting to local time
    char time_buffer[64];  //Buffer to store the formatted date string

    //Formatting the date as "Day Month Date HH:MM:SS Year +GMT"
    strftime(time_buffer, sizeof(time_buffer), "%a %b %d %H:%M:%S %Y %z", time_info);
    return string(time_buffer);
}

//Function to retrieve owner's name for file / directory
string get_ownername(string path) {
    struct stat fd_stat;

    if(stat(path.c_str(), &fd_stat) == -1) {
        perror("./mygit: owner_name");
        exit(1);
    }

    struct passwd* owner_data = getpwuid(fd_stat.st_uid);
    if(owner_data == NULL) {
        perror("./mygit: owner_name: Could not retrieve username for UID");
        exit(1);
    }

    return string(owner_data->pw_name);
}

//Function to convert string to octal int
int octal(string s) {
    string last4 = s.substr(s.size() - 4);
    return stoi(last4, NULL, 8);
}


