#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the write-tree command
void write_tree() {
    string tree_hash = "";  //String to store hash of the tree object

    string path = ".";
    tree_hash = write_tree(path);

    cout << tree_hash << endl;
}

//Function to traverse the current directory and return the hash for it
string write_tree(string path) {
    string blob_dir_path = ".mygit/objects/blobs/";
    string tree_dir_path = ".mygit/objects/trees/";

    string file_contents = "";  //String to store contents of the file to be stored in a tree object

    DIR* dir = opendir(path.c_str());
    if (!dir) {
        perror(("./mygit: write-tree: Error opening directory in: " + path).c_str());
        exit(1);
    }

    struct dirent* entry;
    vector<string> entries;

    while((entry = readdir(dir)) != NULL) {
        string entry_name = entry->d_name;
        if(!mygit_ignore(entry_name)) {
            entries.push_back(entry_name);
        } 
    }

    closedir(dir);

    for(int i = 0; i < entries.size(); i++) {
        string entry_path = path + "/" + entries[i];
        struct stat entry_stat;

        if(stat(entry_path.c_str(), &entry_stat) == 0) {

            //Directory detected: traversing the subdirectory (recursive)
            if(S_ISDIR(entry_stat.st_mode)) {
                string entry_data = get_permissions(entry_path) + " tree " + write_tree(entry_path) + " " + entries[i] + "\n";
                file_contents += entry_data;
            }

            //File detected
            else {
                string entry_data = get_permissions(entry_path) + " blob ";
                string entry_hash = SHA1_hash(entry_path);

                //Checking if the blob object has already been created previously
                if(file_exists(blob_dir_path + entry_hash)) entry_data += entry_hash + " ";
                else entry_data += hash_object(entry_path) + " ";

                entry_data += entries[i] + "\n";
                file_contents += entry_data;
            }
        }
    }

    //Writing file_contents to a temp object file
    string temp_tree_path = tree_dir_path + "temp";
    if(!create_file(temp_tree_path)) {
        cerr << "./mygit: write-tree: Could not create temp tree file" << endl;
        exit(1);
    }

    //Writing into temp file
    int temp_fd = open(temp_tree_path.c_str(), O_WRONLY | O_TRUNC);
    
    if(write(temp_fd, file_contents.c_str(), file_contents.size()) == -1) {
        perror(("./mygit: write-tree: Could not write into temp file in " + temp_tree_path).c_str());
        exit(1);
    }

    string tree_hash = SHA1_hash(temp_tree_path);   //Calculating the hash of the file
    string tree_path = tree_dir_path + tree_hash;   //Path in which tree would be stored

    //Renaming the temp file (overwriting orignal file if it exists)
    if(rename(temp_tree_path.c_str(), tree_path.c_str()) == -1) {
        perror(("./mygit: write-tree: Could not rename temp file in " + temp_tree_path + " to file in " + tree_path).c_str());
        exit(1);
    }

    return tree_hash;
}


