#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the cat-file command
void cat_file(string hash, bool p_flag, bool s_flag, bool t_flag) {
    
    //Checking if file corresponding to given hash exists as either blob or tree
    string blob_path = ".mygit/objects/blobs/" + hash;
    string tree_path = ".mygit/objects/trees/" + hash;
    bool is_blob = file_exists(blob_path);
    bool is_tree = file_exists(tree_path);

    //p-flag
    if(p_flag) {
        if(is_blob) {
            string file_contents = decompress_file(blob_path);
            cout << file_contents << endl;
        }
        else if(is_tree) {
            string file_contents = read_file(tree_path);
            cout << file_contents << endl;
        }
        else cerr << "./mygit: cat-file -p: No such file!" << endl;
        return;
    }

    //s-flag
    else if(s_flag) {
        if(is_blob) {
            string file_contents = decompress_file(blob_path);
            cout << file_contents.size() << endl;
        }
        else if(is_tree) {
            string file_contents = read_file(tree_path);
            cout << file_contents.size() << endl;
        }
        else cerr << "./mygit: cat-file -p: No such file!" << endl;
        return;
    }

    //t-flag
    else if(t_flag) {
        if(is_blob) cout << "blob" << endl;
        else if(is_tree) cout << "tree" << endl;
        else cerr << "./mygit: cat-file -t: No such file!" << endl;
        return;
    }

    //No flags entered
    else {
        cerr << "./mygit: No flags entered!" << endl;
        return;
    }

}



