#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the checkout command
void checkout(string commit_hash) {
    //Stores the path of the index file (staging area)
    string index_path = ".mygit/index";

    //Stores the path of the HEAD file (parent commit)
    string head_path = ".mygit/HEAD";

    //Stores the path of the log file (commit history)
    string log_path = ".mygit/log";

    //Stores the path of the commit object directory
    string commit_dir_path = ".mygit/commits/";

    //Stores the path of the tree/blob object directories
    string blob_dir_path = ".mygit/objects/blobs/";
    string tree_dir_path = ".mygit/objects/trees/";

    //Checking if commit hash provided is valid
    string commit_path = commit_dir_path + commit_hash;
    if(!file_exists(commit_path)) {
        cerr << "./mygit: checkout: Invalid commit hash!" << endl;
        exit(1);
    }

    //Checking if there are files in staging area that have not been commited yet
    if(file_size(index_path) != 0) {
        cerr << "./mygit: checkout: There are file/directories in stage that have not been commited yet!" << endl;
        exit(1);
    }

    //-----------------Reading previous commit-------------------------//
    string commit_file_contents = read_file(commit_path);
    
    //--------------------Emptying current directory-----------------------//
    if(!empty_directory(".")) {
        cerr << "./mygit: checkout: Could not empty current working directory!" << endl;
        exit(1);
    }

    //--------------------Restoring state to previous commit-----------------------//
    vector<string> commit_lines = tokenize(commit_file_contents, "\n");
    vector<string> cwd_snapshot = tokenize(commit_lines[0], " ");
    int cwd_permissions = octal(cwd_snapshot[0]);
    string cwd_type = cwd_snapshot[1];
    string cwd_hash = cwd_snapshot[2];
    string cwd_path = cwd_snapshot[3];

    restore_object(cwd_permissions, cwd_type, cwd_hash, cwd_path);

    for(int i = 1; i < commit_lines.size(); i++) {
        vector<string> line_elements = tokenize(commit_lines[i], " ");
        int entry_permissions = octal(line_elements[0]);
        string entry_type = line_elements[1];
        string entry_hash = line_elements[2];
        string entry_path = line_elements[3];
        
        //Blob
        if(entry_type == "blob") {

            //Checking if entry already exists
            bool is_present = file_exists(entry_path);

            //Already present
            if(is_present) {
                if(!remove_file(entry_path)) {
                    cerr << "./mygit: restore: Could not remove file in " << entry_path << "!" << endl;
                    exit(1);
                }
            }

            restore_object(entry_permissions, entry_type, entry_hash, entry_path);
        }

        //Tree
        else if(entry_type == "tree") {
            
            //Checking if entry already exists
            bool is_present = dir_exists(entry_path);

            //Already present
            if(is_present) {
                if(!remove_dir(entry_path)) {
                    cerr << "./mygit: restore: Could not remove directory in " << entry_path << "!" << endl;
                    exit(1);
                }
            }

            //Creating/Re-creating directory
            if(!create_dir(entry_path, entry_permissions)) {
                cerr << "./mygit: restore: Could not create directory in " << entry_path << "!" << endl;
                exit(1);
            }

            restore_object(entry_permissions, entry_type, entry_hash, entry_path);
        }

        //Invalid case
        else {
            cerr << "./mygit: checkout: Hash " << entry_hash << " is of invalid object type (not tree/blob)!" << endl;
            exit(1);
        }
    }

    //--------------------Updating HEAD with commit_hash-----------------------//

    //Overwriting previous HEAD file
    int head_fd = open(head_path.c_str(), O_WRONLY | O_TRUNC);

    //Error handling
    if(head_fd == -1) {
        cerr << "./mygit: checkout: Could not open file at:" << head_path << "!" << endl;
        exit(1);
    }

    if(write(head_fd, commit_hash.c_str(), commit_hash.size()) == -1) {
        cerr << "./mygit: checkout: Could not write into file at:" << head_path << "!" << endl;
        close(head_fd);
        exit(1);
    }

    close(head_fd);
}

//Function to restore a tree/blob from a hash and path
void restore_object(int permissions, string type, string hash, string path) {
    //Checking if file corresponding to given hash exists as either blob or tree
    string blob_dir_path = ".mygit/objects/blobs/";
    string tree_dir_path = ".mygit/objects/trees/";

    //Blob
    if(type == "blob") {
        string blob_path = blob_dir_path + hash;
        string blob_file_contents = decompress_file(blob_path);
        
        if(!create_file(path, permissions)) {
            cerr << "./mygit: restore: Could not create file in " << path << "!" << endl;
            exit(1);
        }

        int fd = open(path.c_str(), O_WRONLY);

        if(fd == -1) {
            perror(("./mygit: restore: Could not open file in " + path + "!").c_str());
            exit(1);
        }
        if(write(fd, blob_file_contents.c_str(), blob_file_contents.size()) == -1) {
            perror(("./mygit: restore: Could not write into file in " + path + "!").c_str());
            close(fd);
            exit(1);
        }

        close(fd);
    }

    //Tree
    else if(type == "tree") {
        string tree_path = tree_dir_path + hash;
        string tree_file_contents = read_file(tree_path);
        vector<string> content_lines = tokenize(tree_file_contents, "\n");

        for(int i = 0; i < content_lines.size(); i++) {
            vector<string> line_elements = tokenize(content_lines[i], " ");
            int entry_permissions = octal(line_elements[0]);
            string entry_type = line_elements[1];
            string entry_hash = line_elements[2];
            string entry_name = line_elements[3];
            string entry_path = path + "/" + entry_name;

            //Blob entry
            if(entry_type == "blob") restore_object(entry_permissions, entry_type, entry_hash, entry_path);

            //Tree entry
            else if(entry_type == "tree") {
                if(!create_dir(entry_path, entry_permissions)) {
                    cerr << "./mygit: restore: Could not create directory in " << entry_path << "!" << endl;
                    exit(1);
                }
                restore_object(entry_permissions, entry_type, entry_hash, entry_path);
            }

            //Invalid case
            else {
                cerr << "./mygit: restore_object: Hash " << entry_hash << " is of invalid object type (not tree/blob)!" << endl;
                exit(1);
            }
        }
    }

    //Invalid case
    else {
        cerr << "./mygit: restore_object: Hash " << hash << " is of invalid object type (not tree/blob)!" << endl;
        exit(1);
    }
}

