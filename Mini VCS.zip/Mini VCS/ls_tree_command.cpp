#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <dirent.h> //opendir()
#include <time.h> //localtime(), strftime()
#include <pwd.h>    //getpwuid()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <zlib.h>   //file compression

#include <string>
#include <vector>
#include <map>

#include "mygit.h"

using namespace std;

//Function to employ the ls-tree command
void ls_tree(string hash, bool name_flag) {
    
    //Checking if file corresponding to given hash exists as either blob or tree
    string tree_path = ".mygit/objects/trees/" + hash;
    bool is_tree = file_exists(tree_path);

    //--name-only flag
    if(name_flag) {
        if(is_tree) {
            string file_contents = read_file(tree_path);
            vector<string> file_lines = tokenize(file_contents, "\n");

            for(int i = 0; i < file_lines.size(); i++) {
                vector<string> line_tokens = tokenize(file_lines[i], " ");
                cout << line_tokens[line_tokens.size() - 1] << endl;
            }
        }
        else cerr << "./mygit: ls-tree --name-only: No such file!" << endl;
    }

    //No flags entered
    else {
        if(is_tree) {
            string file_contents = read_file(tree_path);
            cout << file_contents << endl;
        }
        else cerr << "./mygit: ls-tree: No such file!" << endl;
    }

}

